<?php exit(0); ?>
{"user_login":"diylivestreams","attempt_time":1585586616,"remote_addr":"185.65.200.254","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/60.0.3112.113 Safari\/537.36"}
{"user_login":"diylivestreams","attempt_time":1585588536,"remote_addr":"74.220.219.132","user_agent":"Mozilla\/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit\/537.36 (KHTML, like Gecko) Chrome\/60.0.3112.113 Safari\/537.36"}
